/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.glassfish.javaee7.batch.lab4;

import java.util.Date;
import javax.batch.api.listener.StepListener;
import javax.batch.runtime.context.JobContext;
import javax.batch.runtime.context.StepContext;
import javax.inject.Inject;
import javax.inject.Named;

@Named
public class PayrollStepListener
    implements StepListener {

    @Inject
    JobContext jobContext;
    
    @Inject
    StepContext stepContext;
    
    @Override
    public void beforeStep() throws Exception {
        System.out.println("\t** PayrollStepListener:: Step started at: " + (new Date())
            + "; stepContext: " + stepContext.getBatchStatus());
    }

    @Override
    public void afterStep() throws Exception {
        System.out.println("\t** PayrollStepListener:: Step completed at: " + (new Date())
            + "; exitStatus: " + stepContext.getBatchStatus());
    }

    
    
}
